import pandas as pd
import numpy as np
import sys
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import warnings

warnings.filterwarnings("ignore")

def main(train_path, test_path):
    # Load data
    train_df = pd.read_csv(train_path)
    test_df = pd.read_csv(test_path)

    # Drop ID column from train, keep IDs for test output
    train_df = train_df.drop(columns=['ID'])
    test_ids = test_df['ID']
    test_df = test_df.drop(columns=['ID'])

    # Encode categorical variables
    categorical_cols = ['Gender', 'Ever_Married', 'Graduated', 'Profession', 'Spending_Score', 'Var_1']
    label_encoders = {}
    for col in categorical_cols:
        le = LabelEncoder()
        train_df[col] = train_df[col].astype(str)
        le.fit(train_df[col])
        train_df[col] = le.transform(train_df[col])
        test_df[col] = test_df[col].astype(str)
        test_df[col] = le.transform(test_df[col])
        label_encoders[col] = le

    # Impute missing numerical values with median
    num_cols = ['Age', 'Work_Experience', 'Family_Size']
    imputer = SimpleImputer(strategy='median')
    train_df[num_cols] = imputer.fit_transform(train_df[num_cols])
    test_df[num_cols] = imputer.transform(test_df[num_cols])

    # Separate features and target
    X = train_df.drop(columns=['Segmentation'])
    y = train_df['Segmentation']

    # Encode target
    target_encoder = LabelEncoder()
    y_encoded = target_encoder.fit_transform(y)

    # Train-validation split
    X_train, X_val, y_train, y_val = train_test_split(
        X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
    )

    # Scale numerical features
    scaler = StandardScaler()
    X_train[num_cols] = scaler.fit_transform(X_train[num_cols])
    X_val[num_cols] = scaler.transform(X_val[num_cols])
    test_df[num_cols] = scaler.transform(test_df[num_cols])

    # Train one-vs-all classifiers (one binary classifier for each class)
    classes = np.unique(y_train)
    models_ova = {}

    for class_label in classes:
        y_binary = (y_train == class_label).astype(int)
        clf = SVC(kernel='rbf', class_weight='balanced', probability=False, random_state=42)
        clf.fit(X_train, y_binary)
        models_ova[class_label] = clf

    def predict_ova(X):
        scores = np.zeros((X.shape[0], len(classes)))
        for class_label, model in models_ova.items():
            decision = model.decision_function(X)
            scores[:, class_label] = decision
        return scores.argmax(axis=1)

    # Validate predictions
    y_val_pred = predict_ova(X_val)
    acc = accuracy_score(y_val, y_val_pred)
    report = classification_report(y_val, y_val_pred, target_names=target_encoder.classes_)
    conf_mat = confusion_matrix(y_val, y_val_pred)

    print(f"Validation Accuracy (One-vs-All SVM): {acc:.4f}")
    print("\nClassification Report:\n", report)
    print("\nConfusion Matrix:\n", conf_mat)

    # Predict on test dataset
    y_test_pred = predict_ova(test_df)
    y_test_labels = target_encoder.inverse_transform(y_test_pred)

    # Save results to ova.csv
    output_ova = pd.DataFrame({'ID': test_ids, 'Segmentation': y_test_labels})
    output_ova.to_csv('ova.csv', index=False)
    print("Predictions saved to ova.csv")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python ova_svm.py <test_csv>")
        sys.exit(1)
    train_path = 'Customer_train.csv'
    test_path = sys.argv[1]
    main(train_path, test_path)
